MINTAGE RESTAURANT KOTTE – RECIPE BOOK UPGRADE
================================================

IMPORTANT: This is an upgrade for the existing repository and Firebase project.
It reuses the Firebase configuration found in the supplied original index.html:
  Project ID: mintage-restaurant-kotte-rpb
  Auth: Firebase Email/Password
  Firestore collection: recipes
No Firebase project is created and no collection reset/migration is run by this app.

PACKAGE CONTENTS
----------------
index.html                 App (Firebase Auth + Firestore compat SDK 10.12.5)
manifest.webmanifest       PWA metadata
service-worker.js          Offline app-shell cache/update versioning
firestore.rules            Suggested security rules
assets/icons/              SVG app icons
assets/fonts/              Reserved for optional self-hosted font files
original-index-reference.html  Supplied original source snapshot for reference

INSTALL INTO THE EXISTING GITHUB REPOSITORY
-------------------------------------------
1. Download and unzip this package.
2. Make a local copy of your current repository before replacing files.
3. Copy the package's index.html, manifest.webmanifest, service-worker.js,
   firestore.rules and assets/ into the ROOT of the existing repository.
4. Do not upload original-index-reference.html unless you want to keep it as a
   private source reference; it is not required by the running app.
5. Commit and push to the existing repository's configured Pages branch.
6. Wait for GitHub Pages deployment, then open the existing Pages URL.
7. Use an existing staff login first. Create a new account only if registration
   is enabled in Firebase Authentication > Sign-in method > Email/Password.

FIREBASE SETUP
--------------
1. Open Firebase Console and select mintage-restaurant-kotte-rpb.
2. Authentication > Sign-in method: ensure Email/Password is enabled.
3. Firestore Database: keep the existing (default) database and recipes collection.
4. Back up Firestore data before changing rules.
5. Review firestore.rules and publish them to the existing database.
6. Confirm the app's authorized domains include the existing GitHub Pages host.
7. Test with a non-production test account and a test recipe before normal use.

PERMISSION MODEL – READ THIS
----------------------------
Every authenticated account can READ, ADD, EDIT and DELETE documents in the
shared /recipes collection. This matches the requested shared staff workflow,
but it means any registered user can change or delete any shared recipe.
Favorites are stored under /users/{uid}/favorites and are per-user. Profile
records are under /users/{uid}. Passwords are managed only by Firebase Auth;
this app never writes passwords to Firestore.

The rules intentionally do not restrict all recipe keys, to avoid rejecting
legacy recipe documents with fields not represented in the upgraded editor.
They validate core fields on writes. Review rules against actual production
records and Firebase Emulator before publishing. Firestore rules are not a
replacement for regular backups.

FEATURES IMPLEMENTED IN THIS PACKAGE
------------------------------------
- Existing Firebase project/config and /recipes collection retained.
- Email/password login, registration, password reset, logout confirmation.
- Three UI languages: English, Sinhala and Tamil; saved in local storage and
  user profile when saved.
- Shared recipe create/edit/delete; ingredients, quantity, unit, category,
  notes, created/updated timestamps and actor labels.
- Built-in categories plus custom category entry.
- Live case-insensitive search across recipe name, ingredient, quantity, unit,
  notes and category; category filter.
- Per-user favorites.
- Dashboard counts and recent recipe lists.
- Profile nickname, language and password change (Firebase reauthentication
  may be required by Firebase for older sessions; the app reports errors).
- JSON export and safe restore: existing document IDs are skipped; no
  existing document is overwritten. Restore requires a backup JSON file.
- PDF selectable-text extraction using PDF.js loaded from a CDN. Pages with
  no selectable text are flagged as likely scanned. Review text is editable;
  an operator can approve a page-text record after manually confirming it.
- Installable PWA shell and best-effort Firestore persistence.
- Append-only recipe activity log when Firestore rules allow it.

INCOMPLETE / NOT CLAIMED AS WORKING
-----------------------------------
- OCR for scanned PDF pages is NOT implemented. The app detects pages with
  little/no selectable text and flags them; it does not recognize page images.
- Automatic recipe boundary detection, ingredient/quantity/unit extraction,
  and duplicate matching are NOT implemented. The PDF review tool deliberately
  preserves extracted page text and asks a human to confirm details. It does
  not invent ingredients or quantities. PDF.js and its worker are loaded from
  cdnjs, so PDF extraction needs network access and CDN availability.
- There is no backend/Cloud Function in this ZIP. A secure OCR pipeline would
  normally upload a PDF to private Cloud Storage, enqueue a Cloud Function,
  process pages using a managed OCR service, store extraction candidates with
  page references/confidence, and require a human approval step before any
  Firestore write. Cloud Vision / Document AI usage can incur charges; storage,
  function invocations, network egress and OCR pages may also be billable.
  Restrict uploads, enforce file-size/page limits, use IAM/service identities,
  avoid public buckets, and never expose service-account keys in browser code.
- Account deletion is intentionally not implemented. Secure deletion requires
  recent authentication and a trusted backend; deleting an Auth user must not
  delete shared recipes.
- No full historical recipe-version recovery. Activity entries are event logs,
  not restorable snapshots. Existing recipe edits are not version archived.
- No automated browser-to-Firebase integration test was possible in this
  package build. Firestore sync, auth, PWA installation and offline writes must
  be tested in the actual Firebase project and target browsers.
- Offline support is best effort only: service worker caches the app shell;
  Firestore persistence depends on browser support/storage policy. Do not treat
  offline writes as guaranteed until tested on the target devices.
- Fonts are loaded from Google Fonts with system fallbacks; fonts are not
  bundled locally in assets/fonts.

TEST CHECKLIST BEFORE PRODUCTION
-------------------------------
[ ] Existing staff login works.
[ ] Register a new test account and verify automatic sign-in.
[ ] Password reset email arrives.
[ ] Add recipe; confirm it appears in Firestore /recipes.
[ ] Edit a legacy recipe and verify its old fields remain intact.
[ ] Delete a test recipe after confirmation.
[ ] Add/remove multiple ingredients.
[ ] Custom category and category filter.
[ ] Search by name, ingredient and category.
[ ] Favorite in account A; verify account B does not see it as favorite.
[ ] Save nickname and switch all three languages.
[ ] Export JSON; restore into a test database; confirm duplicate IDs skip.
[ ] Verify two signed-in browsers receive real-time updates.
[ ] Test offline app-shell launch and online recovery on Android/iOS/desktop.
[ ] Install PWA from browser menu; verify icon and standalone launch.
[ ] Test PDF with text pages and scanned pages; confirm scanned pages are
    flagged and no automatic ingredient data is fabricated.
[ ] Test rules in Firebase Emulator before production deployment.

GITHUB PAGES NOTES
------------------
PWA install and service workers require HTTPS (GitHub Pages provides HTTPS) or
localhost. If the repository uses a project path, the relative asset paths in
this package are designed for that deployment. A first visit needs network
access to load Firebase SDKs and Google Fonts.
