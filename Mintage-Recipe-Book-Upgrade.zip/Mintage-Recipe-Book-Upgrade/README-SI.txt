MINTAGE RESTAURANT KOTTE – RECIPE BOOK UPGRADE
සිංහල ස්ථාපන සහ භාවිත මාර්ගෝපදේශය
================================================

වැදගත්: මෙය ඔබගේ දැනට ඇති GitHub ව්‍යාපෘතිය සහ Firebase ව්‍යාපෘතිය යාවත්කාලීන
කිරීම සඳහා සකස් කර ඇත. අලුත් Firebase ව්‍යාපෘතියක් සාදන්නේ නැත. මුල්
index.html ගොනුවේ තිබූ Firebase සැකසුමම භාවිතා කරයි.

Firebase Project ID: mintage-restaurant-kotte-rpb
Firestore Database: (default)
Collection: recipes
Authentication: Email/Password

දත්ත ආරක්ෂාව
-------------
- දැනට ඇති recipes ලේඛන මකා දැමීමක්, reset කිරීමක් හෝ migration එකක් මෙම
  යෙදුම ආරම්භයේදී සිදු නොකරයි.
- GitHub ගොනු වෙනස් කිරීමට පෙර දැනට ඇති repository එකේ පිටපතක් තබාගන්න.
- Firestore rules වෙනස් කිරීමට පෙර Firebase Console වෙතින් දත්ත backup එකක්
  ලබාගන්න.
- production දත්තවලට බලපාන වෙනස්කම් කිරීමට පෙර test ගිණුමකින් පරීක්ෂා කරන්න.

පවතින GitHub Repository එකට ස්ථාපනය
----------------------------------
1. ZIP ගොනුව unzip කරන්න.
2. ඔබගේ දැනට ඇති GitHub repository එකේ backup/copy එකක් තබාගන්න.
3. ZIP තුළ ඇති index.html, manifest.webmanifest, service-worker.js,
   firestore.rules සහ assets/ ෆෝල්ඩරය repository එකේ root එකට copy කරන්න.
4. original-index-reference.html ගොනුව යෙදුමට අවශ්‍ය නැත. මුල් source reference
   එකක් ලෙස පමණක් තබාගැනීමට අවශ්‍ය නම් පමණක් upload කරන්න.
5. දැනට භාවිතා කරන branch එකට commit කර push කරන්න.
6. GitHub Pages deployment අවසන් වූ පසු දැනට ඇති website URL එක විවෘත කරන්න.

Firebase සැකසුම්
----------------
1. Firebase Console තුළ mintage-restaurant-kotte-rpb project එක විවෘත කරන්න.
2. Authentication > Sign-in method තුළ Email/Password සක්‍රීයද බලන්න.
3. දැනට ඇති Firestore (default) database සහ recipes collection එක තබාගන්න.
4. දත්ත backup එකක් ලබාගෙන පසුව firestore.rules ගොනුව පරීක්ෂා කර publish කරන්න.
5. Authentication හි Authorized domains තුළ GitHub Pages domain එක තිබේද බලන්න.
6. මුලින් test account එකකින් login, add, edit, delete සහ sync පරීක්ෂා කරන්න.

අවසර ක්‍රමය – ඉතා වැදගත්
------------------------
ලියාපදිංචි වී login වන සෑම පරිශීලකයෙකුටම පොදු /recipes collection එකේ
වට්ටෝරු කියවීමට, අලුතින් එක් කිරීමට, සංස්කරණය කිරීමට සහ මකා දැමීමට අවසර ඇත.
ඒ නිසා ඕනෑම ලියාපදිංචි පරිශීලකයෙකුට වෙනත් අයෙකුගේ පොදු වට්ටෝරුවක්ද මකා
දැමිය හැක. මෙය ඔබ ඉල්ලා ඇති shared staff permission ක්‍රමයයි.

Favorites සහ profile දත්ත එක් එක් පරිශීලකයාට වෙන වෙනම තබා ඇත:
/users/{uid}/favorites සහ /users/{uid}.
මුරපද Firestore තුළ ගබඩා නොකරයි; Firebase Authentication භාවිතා කරයි.

මෙහි සම්පූර්ණ ක්‍රියාත්මක කර ඇති දේ
---------------------------------
- පවතින Firebase project/configuration භාවිතය.
- Login, account registration, password reset සහ logout confirmation.
- English, සිංහල සහ தமிழ் interface භාෂා තුන.
- Recipe Add/Edit/Delete, ingredients, quantity, unit, category සහ notes.
- Default categories සහ custom category.
- Recipe name, ingredient, category, notes මත live search.
- එක් එක් user සඳහා වෙනම favorites.
- Dashboard, recent recipes සහ recent updates.
- Nickname/profile සහ language preference.
- JSON backup සහ restore. පවතින document ID එකක් තිබේ නම් එය skip කරයි;
  කිසිදු පවතින recipe එකක් overwrite නොකරයි.
- PDF එකක selectable text ලබාගැනීම. OCR අවශ්‍ය scanned pages වෙනම සලකුණු කරයි.
- PWA app shell cache සහ browser සහාය ඇති විට Firestore persistence.

තවම සම්පූර්ණ කර නොමැති / සාර්ථක බව තහවුරු නොකළ දේ
-------------------------------------------------
1. Scanned PDF පිටු සඳහා OCR ක්‍රියාත්මක කර නැත. මෙම app එක text නැති පිටු
   හඳුනාගෙන OCR අවශ්‍ය බව පෙන්වයි. රූපයෙන් අමුද්‍රව්‍ය කියවන්නේ නැත.
2. PDF එකෙන් recipe boundary, ingredient, quantity, unit ස්වයංක්‍රීයව
   හඳුනාගැනීම සහ duplicate detection ක්‍රියාත්මක කර නැත. ලබාගත් මුල් පෙළ
   මිනිසෙකු විසින් පරීක්ෂා කළ යුතුය. යෙදුම missing quantities/ingredients
   අනුමාන කරන්නේ නැත.
3. OCR සඳහා ආරක්ෂිත backend එකක් අවශ්‍ය වේ. සාමාන්‍ය සැලසුම: PDF private
   Cloud Storage වෙත upload කිරීම, Cloud Function මඟින් OCR සේවාවට යැවීම,
   පිටු අංක සහ confidence සමඟ extraction candidates ගබඩා කිරීම, පසුව
   මිනිස් අනුමැතියෙන් පමණක් recipes collection එකට සුරැකීම. Cloud Vision හෝ
   Document AI, Cloud Functions, Storage, network egress සඳහා ගාස්තු ඇති විය
   හැක. Service-account key එකක් කිසිවිටෙක browser code තුළ නොදමන්න.
4. Account deletion button එකක් දමා නැත. එය recent authentication සහ trusted
   backend එකක් හරහා පමණක් ආරක්ෂිතව කළ යුතුය. User account එක මකා දැමීමෙන්
   shared recipes මකා නොදැමිය යුතුය.
5. සම්පූර්ණ version history recovery නැත. Activity log එකක් පමණක් ඇත; එය
   පැරණි recipe versions නැවත restore කළ හැකි backup එකක් නොවේ.
6. ඔබගේ සජීවී Firebase project එකට සම්බන්ධව සියලු browser/device integration
   tests මෙහිදී ධාවනය කළ නොහැකි විය. පහත checklist එක අනිවාර්යයෙන් පරීක්ෂා කරන්න.
7. Offline app shell cache එක පමණක් සකසා ඇත. Firestore offline persistence
   browser/device සහාය මත රඳා පවතී. සම්පූර්ණ offline synchronization බවට
   සහතිකයක් නොදෙයි.

අවසන් පරීක්ෂණ ලැයිස්තුව
----------------------
[ ] පවතින staff login සාර්ථකද?
[ ] අලුත් account registration සහ auto sign-in.
[ ] Password reset email ලැබේද?
[ ] Recipe එකක් add කර Firestore තුළ පෙනේද?
[ ] පරණ recipe එකක් edit කළ විට පරණ fields ඉතිරිද?
[ ] Test recipe එකක් confirmation පසු delete වේද?
[ ] Ingredients add/remove කළ හැකිද?
[ ] Custom category සහ category filter.
[ ] Name, ingredient සහ category search.
[ ] Account A හි favorite කළ recipe එක Account B හි favorite නොවිය යුතුය.
[ ] Nickname save සහ භාෂා තුන මාරු කිරීම.
[ ] JSON backup download සහ restore; duplicate IDs skip වේද?
[ ] Browser දෙකක real-time sync.
[ ] Android/iPhone/Desktop offline shell සහ නැවත online වීම.
[ ] PWA install සහ app icon.
[ ] Text PDF සහ scanned PDF දෙකම පරීක්ෂා කරන්න.
[ ] Firebase Emulator තුළ rules පරීක්ෂා කිරීම.

PWA සඳහා HTTPS අවශ්‍යය. GitHub Pages HTTPS ලබාදෙයි. මුල් වරට Firebase SDK,
PDF.js සහ Google Fonts ලබාගැනීමට internet අවශ්‍ය වේ.
